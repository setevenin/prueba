"""cuatro controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
import math 
from controller import Robot, Motor, DistanceSensor, Compass
OBJETO = 950.0

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getDevice('motorname')
#  ds = robot.getDevice('dsname')
#  ds.enable(timestep)

sensor_izq = robot.getDevice('izq')
sensor_der = robot.getDevice('der')


sensor_izq.enable(timestep)
sensor_der.enable(timestep)


di = robot.getDevice('motor_DeIzq')
dd = robot.getDevice('motor_DeDer')
ai = robot.getDevice('motor_AtrIzq')
ad = robot.getDevice('motor_TraDer')

di.setPosition(float('inf'))
dd.setPosition(float('inf'))
ai.setPosition(float('inf'))
ad.setPosition(float('inf'))

di.setVelocity(6.0)
dd.setVelocity(6.0)
ai.setVelocity(6.0)
ad.setVelocity(6.0)


#inicializacion compass
compass = robot.getDevice('compass')
flecha = robot.getDevice('flechita')
compass.enable(timestep)


# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # Read the sensors:
    # Enter here functions to read sensor data, like:
    #  val = ds.getValue()

    # Process sensor data here.

    # Enter here functions to send actuator commands, like:
    #  motor.setPosition(10.0)
    obj_der = sensor_der.getValue()
    obj_izq = sensor_izq.getValue()
    if obj_der < OBJETO or obj_izq < OBJETO:
        di.setVelocity(-6.0)
        ai.setVelocity(-6.0)
        
    else:
        di.setVelocity(6.0)
        dd.setVelocity(6.0)
        ai.setVelocity(6.0)
        ad.setVelocity(6.0)
        
    #operacion compass
    norte = compass.getValues()
    angulo = math.atan2(norte[1], norte[0])
    flecha.setPosition(angulo)
     
     
    
    pass

# Enter here exit cleanup code.
