"""GPS controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot, Motor, DistanceSensor, GPS
OBJETO = 950.0

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getDevice('motorname')
#  ds = robot.getDevice('dsname')
#  ds.enable(timestep)

sensor_izq = robot.getDevice('izq')
sensor_der = robot.getDevice('der')

sensor_izq.enable(timestep)
sensor_der.enable(timestep)

di = robot.getDevice('motor_DeIzq')
dd = robot.getDevice('motor_DeDer')
ai = robot.getDevice('motor_AtrIzq')
ad = robot.getDevice('motor_TraDer')

di.setPosition(float('inf'))
dd.setPosition(float('inf'))
ai.setPosition(float('inf'))
ad.setPosition(float('inf'))

di.setVelocity(6.0)
dd.setVelocity(6.0)
ai.setVelocity(6.0)
ad.setVelocity(6.0)

#inicializacion GPS
gps = robot.getDevice('gps')
gps.enable(timestep)



# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # Read the sensors:
    # Enter here functions to read sensor data, like:
    #  val = ds.getValue()

    # Process sensor data here.

    # Enter here functions to send actuator commands, like:
    #  motor.setPosition(10.0)
    obj_der = sensor_der.getValue()
    obj_izq = sensor_izq.getValue()
    if obj_der < OBJETO or obj_izq < OBJETO:
        di.setVelocity(-6.0)
        ai.setVelocity(-6.0)
        
    else:
        di.setVelocity(6.0)
        dd.setVelocity(6.0)
        ai.setVelocity(6.0)
        ad.setVelocity(6.0)
    
    #operacion GPS
    posicion = gps.getValues()
    latitud = gps.convertToDegreesMinutesSeconds(posicion[0])
    altitud = posicion[2]
    longitud = gps.convertToDegreesMinutesSeconds(posicion[1])
    velocidad = gps.getSpeed()
    
    print("Latitud es: ", (format(posicion[0], '.6f')), '[grados]', '/' ,latitud);
    print("Longitud es: ", (format(posicion[1], '.6f')), '[grados]', '/' ,longitud);
    print("Altitud es: ", (format(altitud, '.6f')), '[m]');
    print("Velocidad es:", (format(velocidad, '.6f')), '[m/s]');
   
     
    
    pass

# Enter here exit cleanup code.
